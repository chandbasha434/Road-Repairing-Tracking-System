/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RRTS;

/**
 *
 * @author apiiit123
 */
public class WorkDone {
    public static int CEMENT_USED;
    public static int CEMENT_REQUIRED;
    public static int WATER_USED;
    public static int WATER_REQUIRED;
    public static int SAND_TRIPS_USED;
    public static int SAND_TRIPS_REQUIRED;
    public static int LABOURERS_USED;
    public static int LABOURERS_REQUIRED;
    public static int ComplaintID;
    public static int PercentDone;
    public static String Area;
    
}
