/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RRTS;

/**
 *
 * @author apiiit123
 */
public class Resources {
    public static int CEMENT;
    public static int SAND_TRIPS;
    public static int WATER;
    public static int LABOURERS;
    
}
