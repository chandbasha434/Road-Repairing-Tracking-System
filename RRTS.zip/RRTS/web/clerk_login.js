function submitForm() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Here you can handle the login logic, e.g., send credentials to a server for verification
    console.log('Username:', username);
    console.log('Password:', password);

    // You can add additional logic or AJAX requests here as needed
}
