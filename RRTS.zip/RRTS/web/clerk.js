function submitForm() {
    const roadName = document.getElementById('roadName').value;
    const issue = document.getElementById('issue').value;
    const priority = document.getElementById('priority').value;

    // Here you can handle the form data, e.g., send it to a server or perform further processing
    console.log('Road Name:', roadName);
    console.log('Issue:', issue);
    console.log('Priority:', priority);

    // You can add additional logic or AJAX requests here as needed
}
